# odin-dashboard
This project, named Admin Dashboard, was created as part of the Odin Project curriculum as a way to improve my skills using CSS grid and flexbox. 

Live Preview: https://ray-as.github.io/odin-dashboard/

Odin Project Curriculum: https://www.theodinproject.com/lessons/node-path-intermediate-html-and-css-admin-dashboard
